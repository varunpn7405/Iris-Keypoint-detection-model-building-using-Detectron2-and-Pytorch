# test > 2023-10-23 3:11pm
https://universe.roboflow.com/project-1-dhvtv/test-4cthv

Provided by a Roboflow user
License: CC BY 4.0

